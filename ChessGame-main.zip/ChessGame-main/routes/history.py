from flask import Blueprint, render_template, session, redirect, url_for
from models.db import get_history_for_user

history_bp = Blueprint('history', __name__)

@history_bp.route('/history')
def history():
    if 'user_id' not in session:
        return redirect(url_for('auth.login'))
    rows = get_history_for_user(session['user_id'])
    return render_template('history.html', rows=rows)
