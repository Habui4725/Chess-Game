from flask import Blueprint, render_template, request, jsonify, session, redirect, url_for
from flask_socketio import emit, join_room
from models.db import add_history
from socketio_instance import socketio
import chess
import random
import string

online_bp = Blueprint("online_bp", __name__, url_prefix="/online")

# rooms structure: { room_id: { "board": FEN, "turn": "w"/"b", "players": [], "player_colors": {} } }
rooms = {}

# ------------------- MENU ONLINE -------------------
@online_bp.route("/menu")
def online_menu():
    if "user_id" not in session:
        return redirect(url_for("auth.login"))
    return render_template("menu_online.html")

# ------------------- TẠO -------------------
@online_bp.route("/create", methods=["POST"])
def create_room():
    room_id = ''.join(random.choices(string.ascii_uppercase + string.digits, k=5))
    rooms[room_id] = {"board": chess.Board().fen(), "turn": "w", "players": [], "player_colors": {}}
    return jsonify(ok=True, room_id=room_id)

# ------------------ THAM GIA PHÒNG -------------------
@online_bp.route("/join", methods=["POST"])
def join_room_api():
    room_id = request.form.get("room_id")
    if room_id in rooms:
        return jsonify(ok=True, room_id=room_id)
    return jsonify(ok=False, msg="Phòng không tồn tại")

# ------------------- BÀN CỜ ONLINE -------------------
@online_bp.route("/board/<room_id>")
def board(room_id):
    if room_id not in rooms:
        return "Phòng không tồn tại!", 404
    return render_template("board_online.html", room_id=room_id)

# -------------------- SOCKET EVENTS --------------------
@socketio.on("join")
def on_join(data):
    room = data["room"]
    username = session.get("username", "Người chơi")
    user_id = session.get("user_id")
    join_room(room)

    # Thêm người vào danh sách nếu chưa có
    if username not in rooms[room]["players"]:
        rooms[room]["players"].append(username)
        color = 'w' if len(rooms[room]["players"]) == 1 else 'b'
        rooms[room]["player_colors"][username] = color

    # Khi đủ 2 người thì bắt đầu
    if len(rooms[room]["players"]) == 2:
        emit("message", {"msg": "Người chơi thứ 2 đã vào phòng, bắt đầu trận đấu!"}, to=room)
        emit("update_board", {"fen": rooms[room]["board"]}, to=room)
    else:
        emit("message", {"msg": f"{username} đã tham gia phòng"}, to=room)


@socketio.on("move")
def on_move(data):
    room = data["room"]
    move = data["move"]
    username = session.get("username")
    user_id = session.get("user_id")
    board = chess.Board(rooms[room]["board"])

    # Kiểm tra lượt đi
    player_color = rooms[room]["player_colors"].get(username)
    if (player_color == 'w' and rooms[room]["turn"] != 'w') or (player_color == 'b' and rooms[room]["turn"] != 'b'):
        emit("message", {"msg": "Chưa đến lượt bạn"}, to=request.sid)
        return

    try:
        chess_move = chess.Move.from_uci(move)
        if chess_move in board.legal_moves:
            board.push(chess_move)
            rooms[room]["board"] = board.fen()
            rooms[room]["turn"] = "b" if rooms[room]["turn"] == "w" else "w"

            emit("move", {"move": move}, to=room)
            emit("update_board", {"fen": rooms[room]["board"]}, to=room)

            # ====== Kiểm tra trạng thái ván đấu ======
            if board.is_game_over():
                white_player = None
                black_player = None
                # Xác định ai là trắng, ai là đen
                for uname, clr in rooms[room]["player_colors"].items():
                    if clr == "w":
                        white_player = uname
                    else:
                        black_player = uname

                # Kết quả
                if board.is_checkmate():
                    winner = "Trắng" if board.turn == chess.BLACK else "Đen"
                    result_text = f"{winner} thắng do chiếu hết!"
                    emit("message", {"msg": f"Chiếu hết! {winner} thắng!"}, to=room)
                    emit("game_over", {"result": result_text}, to=room)

                    # Lưu lịch sử cho cả hai người
                    if winner == "Trắng":
                        add_history_for_both(room, white_player, black_player, "Thắng", "Thua")
                    else:
                        add_history_for_both(room, black_player, white_player, "Thắng", "Thua")

                elif board.is_stalemate():
                    result_text = "Hòa do bế tắc!"
                    emit("game_over", {"result": result_text}, to=room)
                    add_history_for_both(room, white_player, black_player, "Hòa", "Hòa")

                elif board.is_insufficient_material():
                    result_text = "Hòa do thiếu quân!"
                    emit("game_over", {"result": result_text}, to=room)
                    add_history_for_both(room, white_player, black_player, "Hòa", "Hòa")

                elif board.is_fivefold_repetition():
                    result_text = "Hòa do lặp lại 5 lần!"
                    emit("game_over", {"result": result_text}, to=room)
                    add_history_for_both(room, white_player, black_player, "Hòa", "Hòa")

                elif board.is_seventyfive_moves():
                    result_text = "Hòa do 75 nước không ăn quân!"
                    emit("game_over", {"result": result_text}, to=room)
                    add_history_for_both(room, white_player, black_player, "Hòa", "Hòa")

        else:
            emit("message", {"msg": "Nước đi không hợp lệ"}, to=request.sid)
    except Exception as e:
        emit("message", {"msg": f"Lỗi: {str(e)}"}, to=request.sid)


@socketio.on("restart_game")
def on_restart(data):
    room = data["room"]
    new_board = chess.Board()
    rooms[room]["board"] = new_board.fen()
    rooms[room]["turn"] = "w"
    emit("restart_board", {"fen": new_board.fen()}, to=room)
    emit("message", {"msg": "Ván mới bắt đầu!"}, to=room)


# ----------------- HÀM LƯU LỊCH SỬ CHUNG -----------------
def add_history_for_both(room, winner_name, loser_name, winner_result, loser_result):
    """Lưu lịch sử cho cả 2 người chơi"""
    from models.db import get_user_by_username, add_history
    w_user = get_user_by_username(winner_name)
    l_user = get_user_by_username(loser_name)

    if w_user and l_user:
        # Người thắng
        add_history(w_user["id"], loser_name, "Online", f"{winner_result} {loser_name}", "...")
        # Người thua
        add_history(l_user["id"], winner_name, "Online", f"{loser_result} {winner_name}", "...")
