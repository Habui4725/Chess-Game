from flask import Blueprint, render_template, request, redirect, url_for, session, jsonify
import chess
import uuid
from models.db import add_history
from services.ai_logic import select_move

game_bp = Blueprint('game', __name__)

# ------------------ OFFLINE ------------------
@game_bp.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('game.menu'))
    return redirect(url_for('auth.login'))

@game_bp.route('/menu')
def menu():
    if 'user_id' not in session:
        return redirect(url_for('auth.login'))
    return render_template('menu.html', username=session['username'])

@game_bp.route('/play')
def play():
    if 'user_id' not in session:
        return redirect(url_for('auth.login'))
    mode = request.args.get('mode', 'easy')
    session['player_color'] = 'white'
    return render_template('play_ai.html', mode=mode)

@game_bp.route('/api/move', methods=['POST'])
def api_move():
    data = request.get_json()
    fen = data.get('fen')
    move = data.get('move')
    mode = data.get('mode', 'easy')
    # dùng python-chess tạo bàn cờ
    board = chess.Board(fen)

    try:
        m = chess.Move.from_uci(move)
        if m not in board.legal_moves:
            return jsonify({'ok': False, 'msg': 'Nước đi không hợp lệ'})
        board.push(m)
    except:
        return jsonify({'ok': False, 'msg': 'Lỗi định dạng nước đi'})

    user_color = chess.WHITE if session.get('player_color') == 'white' else chess.BLACK

    # Kiểm tra game over sau nước người chơi
    if board.is_game_over():
        result = board.result()
        if result == "1-0":
            result_text = "Bạn thắng AI" if user_color == chess.WHITE else "Bạn thua AI"
        elif result == "0-1":
            result_text = "Bạn thắng AI" if user_color == chess.BLACK else "Bạn thua AI"
        else:
            result_text = "Hòa với AI"
        add_history(session['user_id'], 'AI', mode, result_text, move)
        return jsonify({'ok': True, 'ai_move': None, 'fen': board.fen(), 'game_over': True, 'result': result_text})

    # AI đi
    ai_move = select_move(board, mode)
    board.push(ai_move)

    if board.is_game_over():
        result = board.result()
        if result == "1-0":
            result_text = "Bạn thắng AI" if user_color == chess.WHITE else "Bạn thua AI"
        elif result == "0-1":
            result_text = "Bạn thắng AI" if user_color == chess.BLACK else "Bạn thua AI"
        else:
            result_text = "Hòa với AI"
        add_history(session['user_id'], 'AI', mode, result_text, move)
        return jsonify({'ok': True, 'ai_move': ai_move.uci(), 'fen': board.fen(), 'game_over': True, 'result': result_text})

    return jsonify({'ok': True, 'ai_move': ai_move.uci(), 'fen': board.fen(), 'game_over': False})

