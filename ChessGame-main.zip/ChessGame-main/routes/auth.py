import os
from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from flask_bcrypt import Bcrypt
from models.db import get_user_by_username, add_user

# GOOGLE OAUTH
from google_auth_oauthlib.flow import Flow
import google.oauth2.id_token
from pip._vendor import cachecontrol
import google.auth.transport.requests
import requests

auth_bp = Blueprint('auth', __name__)
bcrypt = Bcrypt()

GOOGLE_CLIENT_ID = "292841069530-tg2o850ltvo780n5p3ea040vehql5c7c.apps.googleusercontent.com"
  # BẮT BUỘC THAY BẰNG GOOGLE CLIENT ID
os.environ["OAUTHLIB_INSECURE_TRANSPORT"] = "1"  # cho phép http

# ------------------- REGISTER -------------------
@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    if request.method=='POST':
        username = request.form['username']
        password = request.form['password']
        if get_user_by_username(username):
            flash("Tên người dùng đã tồn tại.")
            return redirect(url_for('auth.register'))
        pw_hash = bcrypt.generate_password_hash(password).decode('utf-8')
        user_id = add_user(username, pw_hash)
        session['user_id'] = user_id
        session['username'] = username
        return redirect(url_for('game.menu'))
    return render_template('register.html')

# ------------------- LOGIN -------------------
@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method=='POST':
        username = request.form['username']
        password = request.form['password']
        user = get_user_by_username(username)
        if not user or not bcrypt.check_password_hash(user['password_hash'], password):
            flash("Sai tên đăng nhập hoặc mật khẩu.")
            return redirect(url_for('auth.login'))
        session['user_id'] = user['id']
        session['username'] = user['username']
        return redirect(url_for('game.menu'))
    return render_template('login.html')

# ------------------- LOGOUT -------------------
@auth_bp.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('auth.login'))

# ------------------- GOOGLE LOGIN -------------------
@auth_bp.route("/auth/google")
def google_auth():
    #tạo flow lấy id và secret qua json, yêu cầu gửi profile + email và mở khóa đăng nhập + gửi code qua redirect_uri
    flow = Flow.from_client_secrets_file(
        "client_secret.json",
        scopes=[
            "https://www.googleapis.com/auth/userinfo.profile",
            "https://www.googleapis.com/auth/userinfo.email",
            "openid"
        ],
        redirect_uri="https://extendable-dortha-gibingly.ngrok-free.dev/auth/google/callback"
    )
    # Tạo URL đăng nhập và chuyển user về trang đăng nhập GG
    auth_url, _ = flow.authorization_url()
    return redirect(auth_url)


@auth_bp.route("/auth/google/callback")
def google_callback():
    flow = Flow.from_client_secrets_file(
        "client_secret.json",
        scopes=[
            "https://www.googleapis.com/auth/userinfo.profile",
            "https://www.googleapis.com/auth/userinfo.email",
            "openid"
        ],
        redirect_uri="https://extendable-dortha-gibingly.ngrok-free.dev/auth/google/callback"
    )

    # Gửi code để nhận url chứa access token + id_token
    flow.fetch_token(authorization_response=request.url)
    # Chứa token gọi API GG or xác thực user
    credentials = flow.credentials

    # Tạo session bọc cache để gửi request kiểm tra token nhanh hơn
    request_session = requests.session()
    cached_session = cachecontrol.CacheControl(request_session)
    # Tạo đối tượng GG gửi request kiểm tra token
    token_request = google.auth.transport.requests.Request(session=cached_session)

    # Kiểm tra id_token có hợp lệ kh và lấy email
    id_info = google.oauth2.id_token.verify_oauth2_token(
        credentials._id_token, token_request, GOOGLE_CLIENT_ID
    )
    google_email = id_info["email"]

    # Kiểm tra tồn tại user trong DB
    user = get_user_by_username(google_email)
    if not user:
        pw_hash = bcrypt.generate_password_hash("google_oauth").decode("utf-8")
        user_id = add_user(google_email, pw_hash)
    else:
        user_id = user["id"]

    # Tạo session cho user
    session["user_id"] = user_id
    session["username"] = google_email

    return redirect(url_for("game.menu"))

