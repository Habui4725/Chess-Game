from datetime import datetime
import mysql.connector
from config import DB_CONFIG

def get_conn():
    return mysql.connector.connect(**DB_CONFIG)

def init_db():
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(255) UNIQUE NOT NULL,
        password_hash VARCHAR(255) NOT NULL,
        created_at DATETIME NOT NULL
    )
    """)
    cur.execute("""
    CREATE TABLE IF NOT EXISTS history (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        opponent VARCHAR(255) NOT NULL,
        difficulty VARCHAR(50) NOT NULL,
        result VARCHAR(50) NOT NULL,
        moves TEXT,
        created_at DATETIME NOT NULL,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )
    """)
    conn.commit()
    cur.close()
    conn.close()

def get_user_by_username(username):
    conn = get_conn()
    cur = conn.cursor(dictionary=True)
    cur.execute("SELECT * FROM users WHERE username=%s", (username,))
    row = cur.fetchone()
    cur.close()
    conn.close()
    return row

def add_user(username, password_hash):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO users (username, password_hash, created_at) VALUES (%s,%s,%s)",
        (username, password_hash, datetime.utcnow())
    )
    conn.commit()
    uid = cur.lastrowid
    cur.close()
    conn.close()
    return uid

def add_history(user_id, opponent, difficulty, result, moves):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO history (user_id, opponent, difficulty, result, moves, created_at) VALUES (%s,%s,%s,%s,%s,%s)",
        (user_id, opponent, difficulty, result, moves, datetime.utcnow())
    )
    conn.commit()
    cur.close()
    conn.close()

def get_history_for_user(user_id):
    conn = get_conn()
    cur = conn.cursor(dictionary=True)
    cur.execute("SELECT * FROM history WHERE user_id=%s ORDER BY created_at DESC", (user_id,))
    rows = cur.fetchall()
    cur.close()
    conn.close()
    return rows
