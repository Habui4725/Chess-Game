// =================== HÀM HỖ TRỢ ===================

// Chuyển FEN string thành mảng 2 chiều 8x8
// Ví dụ: "8/8/8/8/8/8/8/8" -> [['.', '.', ..., '.'], ...]
function fenToBoardArray(fen) {
    const rows = fen.split(" ")[0].split("/"); // Lấy phần FEN mô tả bàn cờ
    const board = [];
    for (let r of rows) {
        const rowArr = [];
        for (let c of r) {
            if (!isNaN(c)) {
                // Nếu là số, thêm đúng số ô trống '.'
                for (let i = 0; i < parseInt(c); i++) rowArr.push(".");
            } else {
                rowArr.push(c); // Nếu là ký hiệu quân cờ
            }
        }
        board.push(rowArr);
    }
    return board;
}

// Chuyển tọa độ row, col thành ký hiệu ô cờ chuẩn (ví dụ e2, e4)
function rcToSquare(row, col) {
    const files = ['a','b','c','d','e','f','g','h'];
    return files[col] + (8 - row);
}

// Vẽ lại bàn cờ dựa trên FEN
// - boardDiv: div chứa bàn cờ
// - onCellClick: callback khi click ô
function renderBoardFromFEN(fen, boardDiv, onCellClick) {
    const boardArr = fenToBoardArray(fen);

    // Map ký hiệu FEN -> tên ảnh
    const pieceMap = {
        "P": "wp", "R": "wr", "N": "wn", "B": "wb", "Q": "wq", "K": "wk",
        "p": "bp", "r": "br", "n": "bn", "b": "bb", "q": "bq", "k": "bk",
        ".": "empty"
    };

    // Xóa bàn cờ cũ trước khi vẽ lại
    boardDiv.innerHTML = "";

    // Duyệt từng hàng
    for (let r = 0; r < 8; r++) {
        const rowDiv = document.createElement("div");
        rowDiv.className = "row";

        for (let f = 0; f < 8; f++) {
            const cell = document.createElement("div");
            // Gán class màu trắng/đen xen kẽ
            cell.className = "cell " + ((r + f) % 2 === 0 ? "white" : "black");

            const piece = boardArr[r][f];
            const imgName = pieceMap[piece];

            // Nếu có quân cờ, tạo <img>
            if (imgName !== "empty") {
                const img = document.createElement("img");
                img.src = `/static/images/${imgName}.png`;
                img.style.width = "100%";
                img.style.height = "100%";
                cell.appendChild(img);
            }

            // Bắt sự kiện click ô
            cell.onclick = () => onCellClick(r, f);

            rowDiv.appendChild(cell);
        }
        boardDiv.appendChild(rowDiv);
    }
}

// Xử lý khi click ô cờ
// - gameState chứa trạng thái mutable (selected, gameOver) và các biến cần thiết
function onCellClick(row, col, gameState) {
    const { gameOver, selected, status, socket, room_id } = gameState;

    if (gameOver.value) return; // Nếu trận kết thúc, không đi nữa

    if (!selected.value) {
        // Chưa chọn ô trước đó -> chọn ô hiện tại
        selected.value = { row, col };
        status.innerText = `Đã chọn ô (${row},${col})`;
    } else {
        // Đã chọn ô trước -> gửi nước đi lên server
        const from = rcToSquare(selected.value.row, selected.value.col);
        const to = rcToSquare(row, col);
        const move = from + to; // Ví dụ "e2e4"
        socket.emit("move", { room: room_id, move });
        selected.value = null; // Reset selection
    }
}


// =================== HÀM CHÍNH ===================
function startOnlineChess(room_id) {
    const socket = io(); // Kết nối WebSocket
    const boardDiv = document.getElementById("board"); // div chứa bàn cờ
    const status = document.getElementById("status");   // div hiển thị trạng thái
    const replayBtn = document.getElementById("replay-btn"); // nút chơi lại

    // State mutable để truyền cho các hàm ngoài
    const gameState = {
        selected: { value: null },   // ô đang chọn
        gameOver: { value: false },  // trạng thái ván đấu
        status,
        socket,
        room_id
    };

    // Tham gia phòng
    socket.emit("join", { room: room_id });

    // ================== SỰ KIỆN SOCKET ==================
    // Khi có thông báo từ server
    socket.on("message", data => status.innerText = data.msg);

    // Khi nhận nước đi của đối thủ
    socket.on("move", data => status.innerText = "Nước đi: " + data.move);

    // Khi nhận FEN mới để render lại bàn cờ
    socket.on("update_board", data => renderBoardFromFEN(data.fen, boardDiv, (r, c) => onCellClick(r, c, gameState)));

    // Khi trận đấu kết thúc
    socket.on("game_over", data => {
        status.innerText = "Trận đấu kết thúc: " + data.result;
        alert("Trận đấu kết thúc: " + data.result);
        gameState.gameOver.value = true;
        replayBtn.style.display = "inline-block"; // hiện nút chơi lại
    });

    // ================== INIT ==================
    // Render bàn cờ trống ban đầu
    renderBoardFromFEN("8/8/8/8/8/8/8/8", boardDiv, (r, c) => onCellClick(r, c, gameState));

    // ================== NÚT CHƠI LẠI ==================
    replayBtn.onclick = () => {
        socket.emit("restart_game", { room: room_id });
        replayBtn.style.display = "none";
        gameState.gameOver.value = false;
        status.innerText = "Đang khởi tạo lại ván mới...";
    };

    // Khi server gửi FEN mới cho ván mới
    socket.on("restart_board", data => {
        renderBoardFromFEN(data.fen, boardDiv, (r, c) => onCellClick(r, c, gameState));
        status.innerText = "Ván mới đã bắt đầu!";
    });
}
