// static/js/chess_board.js
window.startChess = function(mode) {
    let boardFen = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";
    const boardDiv = document.getElementById("board");
    const status = document.getElementById("status");
    const overlay = document.getElementById("overlay");
    const winnerText = document.getElementById("winner-text");
    const replayBtn = document.getElementById("replay-btn");
    const menuBtn = document.getElementById("menu-btn");
    const overlayReplayBtn = document.getElementById("overlay-replay-btn");
    const overlayMenuBtn = document.getElementById("overlay-menu-btn");

// thiết lập click cho mỗi ô
overlayReplayBtn.onclick = () => {
    overlay.classList.remove("active");
    boardDiv.style.opacity = 1;
    startChess(mode);
};

overlayMenuBtn.onclick = () => {
    window.location.href = "/menu";
};

    let selected = null;
    let lastMovePlayer = null;
    let lastMoveAI = null;

    // Nút replay
    replayBtn.onclick = () => {
        overlay.classList.remove("active");
        boardDiv.style.opacity = 1;
        startChess(mode); // reset bàn cờ
    };

    // Nút menu
    menuBtn.onclick = () => { window.location.href = "/menu"; };

    // phân tích FEN gửi vào tạo DOM grid 8x8 và đặt image cho quân cờ theo kí tự
    function render(fen) {
        boardDiv.innerHTML = "";
        const rows = fen.split(" ")[0].split("/");
        rows.forEach((r, rowIndex) => {
            const rowDiv = document.createElement("div");
            rowDiv.className = "row";
            let file = 0;
            r.split("").forEach(c => {
                if (!isNaN(c)) {
                    for (let i=0; i<parseInt(c); i++) {
                        const cell = createCell(rowIndex, file);
                        rowDiv.appendChild(cell);
                        file++;
                    }
                } else {
                    const cell = createCell(rowIndex, file, c);
                    rowDiv.appendChild(cell);
                    file++;
                }
            });
            boardDiv.appendChild(rowDiv);
        });

        highlightMove(lastMovePlayer, "#ffff99"); // player yellow
        highlightMove(lastMoveAI, "#90ee90");     // AI green
    }

    // Thêm ảnh quân cờ trong images vào từng kí tự quân cờ ở render(fen)
    function createCell(row, file, pieceChar=null) {
        const cell = document.createElement("div");
        cell.className = "cell " + ((row+file)%2===0 ? "white":"black");
        if (pieceChar) {
            const piece = (pieceChar===pieceChar.toUpperCase()?"w":"b")+pieceChar.toLowerCase();
            const img = document.createElement("img");
            img.src = `/static/images/${piece}.png`;
            img.style.width = "100%";
            img.style.height = "100%";
            cell.appendChild(img);
        }
        cell.onclick = () => onCellClick(row, file);
        return cell;
    }

    // Highlight nước đi cuối
    function highlightMove(move, color) {
        if (!move) return;
        const [fr, ff, tr, tf] = move;
        boardDiv.children[fr].children[ff].style.backgroundColor = color;
        boardDiv.children[tr].children[tf].style.backgroundColor = color;
    }

    // Lấy quân trên ô
    function getPieceAt(row, file) {
        const rows = boardFen.split(" ")[0].split("/");
        let f=0;
        for (const ch of rows[row]) {
            if (!isNaN(ch)) f+=parseInt(ch);
            else {
                if(f===file) return ch;
                f++;
            }
        }
        return null;
    }

    // Chuyển nước đi sang UCI
    function convertToUCI(from, to, promotion='') {
        const files="abcdefgh", ranks="87654321";
        return files[from.file]+ranks[from.row]+files[to.file]+ranks[to.row]+promotion;
    }

    // Xử lý click ô
    function onCellClick(row, file){
        const piece = getPieceAt(row, file);
        if(!selected){
            if(!piece) return;
            selected = {row: row, file: file};
            status.innerText = `Đã chọn quân: ${piece.toUpperCase()} tại ${row},${file}`;
            return;
        }

        const from = selected;
        const to = {row: row, file: file};
        const movingPiece = getPieceAt(from.row, from.file);
        let promotion = '';
        if(movingPiece.toLowerCase()==='p'){
            if((movingPiece==='P'&&to.row===0)||(movingPiece==='p'&&to.row===7)) promotion='q';
        }

        const moveStr = convertToUCI(from, to, promotion);

        fetch('/api/move',{
            method:'POST',
            headers:{'Content-Type':'application/json'},
            body: JSON.stringify({fen:boardFen, move:moveStr, mode:mode})
        }).then(r=>r.json())
        .then(data=>{
            if(data.ok){
                lastMovePlayer = [from.row, from.file, to.row, to.file];
                boardFen = data.fen;

                if(data.ai_move){
                    const f0 = data.ai_move.charCodeAt(0)-97;
                    const r0 = 8-parseInt(data.ai_move[1]);
                    const f1 = data.ai_move.charCodeAt(2)-97;
                    const r1 = 8-parseInt(data.ai_move[3]);
                    lastMoveAI = [r0,f0,r1,f1];
                }

                render(boardFen);

                if(data.game_over){
                    winnerText.innerText = data.result;
                    overlay.classList.add("active");
                    boardDiv.style.opacity = 0.5;
                } else {
                    status.innerText = `AI đi: ${data.ai_move}`;
                }
            } else {
                status.innerText = data.msg;
            }
        });

        selected = null;
    }

    render(boardFen);
    status.innerText = "Click quân để đi, nước đi vừa đi sẽ hiện màu";
};
