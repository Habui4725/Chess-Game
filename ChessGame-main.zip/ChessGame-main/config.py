DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': '',
    'database': 'chess_web'
}

SECRET_KEY = 'random_secret_key_12345'  # thay bằng key mạnh hơn khi deploy
